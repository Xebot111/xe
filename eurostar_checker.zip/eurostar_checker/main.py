import config
import os
import asyncio
from logging import getLogger, DEBUG, FileHandler, Formatter
from nextcord import Intents, Status, Streaming
from nextcord.ext import commands
from asyncio import run
from os import listdir
import datetime

# Setting up logging
logger = getLogger("nextcord")
logger.setLevel(DEBUG)
handler = FileHandler(filename="log/discord.log", encoding="utf-8", mode="w")
handler.setFormatter(Formatter("%(asctime)s:%(levelname)s:%(name)s: %(message)s"))
logger.addHandler(handler)

# Setting up intents for the bot
intents = Intents.default()
intents.message_content = True

React = commands.Bot(
    command_prefix="!",
    case_insensitive=True,
    help_command=None,
    intents=intents,
    strip_after_prefix=True,
)

os.system('cls')

# Function to load cogs
async def load_cogs():
    for file in listdir("cogs"):
        if file.endswith(".py") and not file.startswith("__COMING__SOON"):
            try:
                React.load_extension(f"cogs.{file[:-3]}")
                print(f"Successfully loaded {file[:-3]}")
            except Exception as e:
                print(f"Unable to load {file[:-3]}: {e}")

# Bot ready event
@React.event
async def on_ready():
    print(f"{React.user} is online")
    await React.change_presence(
        status=Status.idle,
        activity=Streaming(
            name="Eurostar ♱ By Xe",
            url="https://www.youtube.com/watch?v=cphJ5oMB1vs&list=RDcphJ5oMB1vs&index=1",
        ),
    )

@React.event
async def on_message(message):
    if message.author == React.user:
        return
    await React.process_commands(message)

# # Importing and running the byfour.py script directly
# import byfour  # Make sure byfour.py is in the same folder as this file

if __name__ == "__main__":
    async def start_bot():
        await load_cogs()  # Load all cogs from the cogs folder
        await React.start(config.Bot_token, reconnect=True)

    run(start_bot())
