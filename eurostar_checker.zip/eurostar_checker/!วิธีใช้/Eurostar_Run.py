import subprocess

# Run the bot script
print("Running main.py...")
subprocess.run(["py", "main.py"])

