import subprocess
import sys
import ensurepip


def install_packages():
    """Install required packages using pip."""
    packages = [
        "nextcord",
        "discord",
        "humanize",
        "httpx",
        "beautifulsoup4",
        "requests",
        "xmltodict"
    ]
    for package in packages:
        print(f"Installing {package}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
    print("All packages installed.")

if __name__ == "__main__":
    install_packages()
