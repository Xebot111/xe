Bot_token = "MTI5OTM4NjcyMjk3ODc2Mjg2NA.Gugx2f.djBjzEtLuEt2dvkKUir8wFXvjubON8sePULt6I" #ใส่ token bot
Bot_prefix = "!" # คำสั่งในการเริ่มใช้