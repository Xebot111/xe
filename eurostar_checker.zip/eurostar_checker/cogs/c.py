from nextcord.ext import commands
from nextcord.ui import View, Button, button
from nextcord import Interaction, Embed, ButtonStyle, Member
import xmltodict
import requests
from bs4 import BeautifulSoup
from httpx import get

class c(commands.Cog):
    def __init__(self, React: commands.Bot):
        self.React = React
        self.servers = {
            '1': '103.91.190.189:30120',
            '2': '103.91.190.68:30120',
            '3': '103.208.27.132:30120',
            '4': '103.91.190.230:30120',
            '5': '103.208.27.17:30120',
            '6': '103.208.27.176:30120',
            '7': '103.91.190.164:30120',
            '8': '103.91.190.171:30120',
            '9': '103.91.190.103:30120',
            '10': '103.91.190.233:30120'
        }

    def steam3_to_steamid64(self, steam3_hex: str) -> int:
        steam3_hex_value = steam3_hex.replace("steam:", "")
        decimal_value = int(steam3_hex_value, 16)
        return decimal_value

    class SteamProfile:
        def __init__(self, steam_id64):
            self.url = f'https://steamcommunity.com/profiles/{steam_id64}'
            if self.exists():
                self.profile_data = self.get_xml_mainpage()["profile"]
                self.mainpage = self.get_mainpage()
            else:
                print("Profile does not exist")
                self.profile_data = None
                self.mainpage = None

            self.output_directory = self.make_output_dir()
            self.output_dict = {"profileUrl": self.url}

        def make_output_dir(self):
            output_name = "steamint_" + self.profile_data["steamID64"] if self.profile_data else "steamint_unknown"
            return output_name

        def get_mainpage(self):
            request = requests.get(self.url)
            html = BeautifulSoup(request.text, 'html.parser')
            user_content = html.find('div', {"id": "responsive_page_template_content"})
            return user_content

        def exists(self):
            xml_mainpage = self.get_xml_mainpage()
            if "response" in xml_mainpage and "error" in xml_mainpage["response"]:
                return False
            else:
                return True

        def get_xml_mainpage(self):
            xml_page_url = f"{self.url}/?xml=1"
            xml_page = requests.get(xml_page_url)
            profile_data = xmltodict.parse(xml_page.text)
            return profile_data

        def get_actual_persona(self):
            if self.profile_data:
                persona = self.profile_data.get("steamID", "Unknown")
                return persona
            return "Unknown"

        def get_real_name(self):
            if self.profile_data:
                return self.profile_data.get("realname", "No real name available.")
            return "No real name available."

        def get_location(self):
            if self.profile_data:
                return self.profile_data.get("location", "Not available")
            return "Not available"

        def get_status(self):
            current_status = self.profile_data.get("stateMessage", "")
            current_status = current_status.replace("<br/>", " ")
            if current_status == "Source SDK Base 2007":
                current_status = "FiveM"
            return current_status

        def get_profile_picture(self):
            if self.mainpage:
                avatar_div = self.mainpage.find('div', {'class': 'playerAvatar'})
                if avatar_div:
                    inner_div = avatar_div.find('div', {'class': 'playerAvatarAutoSizeInner'})
                    if inner_div:
                        images = inner_div.find_all('img')
                        for image in images:
                            img_link = image.get("src")
                            if img_link and not image.find_parent('div', class_='profile_avatar_frame'):
                                if img_link.lower().endswith(".jpg"):
                                    return img_link
            return "No profile picture found"

    class FivemButton(View):
        def __init__(self, React: commands.Bot, Member: Member, id: str, did: str, url: str, steam_id64: int):
            super().__init__(timeout=None)
            self.React = React
            self.Member = Member
            self.did = did
            self.id = id
            self.url = url
            self.steam_id64 = steam_id64
            self.steam_profile = c.SteamProfile(steam_id64)

        @button(label='ตรวจสอบข้อมูลสตรีม', style=ButtonStyle.green, emoji="🔎")
        async def lookup(self, button: Button, interaction: Interaction):
            if interaction.user == self.Member:
                try:
                    user = await self.React.fetch_user(int(self.did))
                    profile_pic_url = self.steam_profile.get_profile_picture()

                    embed = Embed(
                        color=0x9b59b6,
                        description=f"""
> ``🎮 SteamID64``: {self.steam_id64}
> ``🙎‍♂️ Name``: {self.steam_profile.get_actual_persona()}
> ``📝 Real Name``: {self.steam_profile.get_real_name()}
> ``📍 Location``: {self.steam_profile.get_location()}
> ``📜 Status``: {self.steam_profile.get_status()}
> ``🖼️ Profile Image``: [Link to Image]({profile_pic_url})
"""
                    )
                    embed.set_author(name="STEAM LOOKUP", icon_url="https://s13.gifyu.com/images/SP808.gif")

                    if profile_pic_url != "No profile picture found":
                        embed.set_thumbnail(url=profile_pic_url)
                    else:
                        embed.set_thumbnail(url="https://s13.gifyu.com/images/SP808.gif")

                    await interaction.message.reply(embed=embed)
                except Exception as e:
                    error_embed = Embed(
                        color=0x206694,
                        description="``❌`` ``|`` ไม่พบข้อมูลของผู้ใช้นี้."
                    )
                    await interaction.message.reply(embed=error_embed)

    @commands.command()
    async def cc(self, ctx: commands.Context, ip: str, port: str, id: str):
        embed = Embed(
            color=0xFFD06B,
            description="``🕐`` ``|`` กําลังโหลดกรุณารอสักครู่..."
        )
        message = await ctx.reply(embed=embed)

        try:
            port = int(port)
            id = int(id)

            # Fetch data from itools.zone API
            url = f'https://itools.zone/fivem/?ip_address={ip}&port={port}'
            response = get(url)

            if response.status_code != 200:
                raise ValueError("Failed to retrieve data from the API.")

            data = response.json()

            player_info = next((player for player in data['players'] if player['id'] == id), None)

            if not player_info:
                embed = Embed(
                    color=0x9b59b6,
                    description=f"``❌`` ``|`` ไม่พบผู้เล่นไอดี {id}"
                )
                return await message.edit(embed=embed)

            name = player_info['name']
            ping = player_info['ping']
            identifiers = player_info['identifiers']

            discord_identifier = ""
            for identifier in identifiers:
                if identifier.split(":")[0] == "discord":
                    discord_identifier = identifier.split(":")[1]
                    break

            discord_user_info = ""
            if discord_identifier:
                try:
                    discord_user = await self.React.fetch_user(int(discord_identifier))
                    discord_user_info = f"""
> ``♱ Discord``: {str(discord_user)}
> ``🔥 Discord Tag``: {discord_user.mention}
"""
                except Exception:
                    discord_user_info = "> ``❌`` ``|`` ไม่พบข้อมูลของผู้ใช้นี้."

            steam_hex = None
            steam_id64 = None
            for identifier in identifiers:
                if identifier.startswith("steam:"):
                    steam_hex = identifier.split(":")[1]
                    steam_id64 = self.steam3_to_steamid64(identifier.split(":")[1])
                    break

            # Fetch the server status details from the response
            try:
                server_info = data.get("dynamic", {})
                clients = server_info.get("clients", "N/A")
                sv_maxclients = server_info.get("sv_maxclients", "N/A")
                sv_hostname = server_info.get("hostname", "N/A")
            except Exception:
                clients = "N/A"
                sv_maxclients = "N/A"
                sv_hostname = "N/A"

            # Create the button here
            fivem_button = self.FivemButton(self.React, ctx.author, str(id), str(ctx.author.id), url, steam_id64)

            embed = Embed(
                color=0x9b59b6,
                description=f"""
## 🌐 {sv_hostname}
> ``🟢 Online`` : {clients}/{sv_maxclients}
> ``⚡ ID`` : {id}
> ``🙎‍♂️ Name`` : {name}
> ``🎮 Steam Hex`` : {steam_hex}
> ``📶 Ping`` : {ping} ms
{discord_user_info}
"""
            )
            embed.set_author(name="FIVEM SERVER PLAYER CHECKER", icon_url="https://s13.gifyu.com/images/SP808.gif")

            if discord_user_info:
                if discord_user.avatar:
                    embed.set_thumbnail(url=discord_user.avatar.url)
                else:
                    embed.set_thumbnail(url="https://s13.gifyu.com/images/SP808.gif")
                if discord_user.banner:
                    embed.set_image(url=discord_user.banner.url)
                else:
                    embed.set_image(url="https://s7.gifyu.com/images/SP8jB.gif")

            # Send the message with the button
            await message.edit(embed=embed)
            await message.reply(view=fivem_button)

        except ValueError:
            embed = Embed(
                color=0xFFD06B,
                description="``❌`` ``|`` ค่าที่กรอกไม่ถูกต้อง."
            )
            await message.edit(embed=embed)

    @commands.command()
    async def c(self, ctx, server_number: str, id: str):
        ip = self.servers.get(server_number)
        if ip:
            await self.cc(ctx, ip.split(":")[0], ip.split(":")[1], id)

def setup(React: commands.Bot):
    React.add_cog(c(React))
