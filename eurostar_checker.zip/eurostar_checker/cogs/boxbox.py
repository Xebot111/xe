from nextcord.ext import commands, tasks
from nextcord import Embed
import aiohttp
import datetime
import json  # Import json for manual decoding

class BoxBoxCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.send_auto_1.start()  # Start the first loop for the first URL
    @tasks.loop(minutes=1)
    async def send_auto_1(self):
        """First loop for the first URL"""
        url_players = 'http://92.220.101.61:30120/players.json'
        url_server_info = 'https://itools.zone/fivem/?ip_address=92.220.101.61&port=30120'
        # Fetch the players data
        async with aiohttp.ClientSession() as session:
            async with session.get(url_players) as response_players:
                if response_players.status == 200:
                    try:
                        raw_content_players = await response_players.read()
                        playerJson = json.loads(raw_content_players.decode('utf-8'))
                        if playerJson:  # Check if there are players in the list
                            # Fetch the server info (clients and sv_maxclients)
                            async with session.get(url_server_info) as response_server:
                                if response_server.status == 200:
                                    try:
                                        raw_content_server = await response_server.read()
                                        server_info = json.loads(raw_content_server.decode('utf-8'))
                                        clients = server_info.get("dynamic", {}).get("clients", "N/A")
                                        sv_maxclients = server_info.get("dynamic", {}).get("sv_maxclients", "N/A")
                                        sv_hostname = server_info.get("dynamic", {}).get("hostname", "N/A")
                                    except Exception:
                                        clients = "N/A"
                                        sv_maxclients = "N/A"
                                        sv_hostname = "N/A"
                                else:
                                    clients = "N/A"
                                    sv_maxclients = "N/A"
                                    sv_hostname = "N/A"
                            # Channels to send the embed to
                            channel_ids = [1306279443475599430, 1320902460834840660]  # Replace with your actual channel IDs
                            channels = [self.bot.get_channel(channel_id) for channel_id in channel_ids]

                            # Iterate through each player in the list
                            for player_data in playerJson:
                                id = player_data.get('id', 'N/A')
                                name = player_data.get('name', 'N/A')
                                identifiers = player_data.get('identifiers', [])
                                steam_hex = next((i for i in identifiers if i.startswith("steam:")), "N/A")
                                discord_id = next((i.split(":")[1] for i in identifiers if i.startswith("discord:")), None)
                                ping = player_data.get('ping', 'N/A')

                                # Create the embed
                                embed = Embed(
                                    title="BoxBox Check ♱",
                                    description=f"""
                                    > ``🌐 Server`` : {sv_hostname}
                                    > ``⚡ ID`` : {id}
                                    > ``🙎‍♂️ Name`` : {name}
                                    > ``🎮 Steam Hex`` : {steam_hex}
                                    > ``📶 Ping`` : {ping} ms
                                    > ``🟢 Online`` : {clients}/{sv_maxclients}
                                    > ``📝 Check`` :```!check 92.220.101.61 30120 {id}```
                                    """,
                                    color=0x9b59b6,
                                    timestamp=datetime.datetime.utcnow()
                                )
                                embed.set_footer(text="Eurostar ...")
                                embed.set_image(url="https://s7.gifyu.com/images/SP8jB.gif")
                                embed.set_thumbnail(url="https://s13.gifyu.com/images/SP808.gif")

                                # Fetch Discord user profile if a Discord ID exists
                                if discord_id:
                                    try:
                                        discord_user = await self.bot.fetch_user(int(discord_id))
                                        if discord_user:
                                            # Add the Discord user's avatar and banner
                                            if discord_user.avatar:
                                                embed.set_thumbnail(url=discord_user.avatar.url)
                                            if discord_user.banner:
                                                embed.set_image(url=discord_user.banner.url)

                                            # Add Discord-specific details
                                            embed.add_field(name="Discord Profile", value=f"""> ``🔥 Discord``: {discord_user.mention}""", inline=False)
                                    except Exception:
                                        embed.add_field(name="Discord Profile", value="Unable to fetch profile.", inline=False)

                                # Send the embed to both channels
                                for channel in channels:
                                    await channel.send(embed=embed)

                    except Exception:
                        pass  # Silence errors during JSON processing
                else:
                    pass  # Silence non-200 HTTP response errors

def setup(bot):
    bot.add_cog(BoxBoxCog(bot))
