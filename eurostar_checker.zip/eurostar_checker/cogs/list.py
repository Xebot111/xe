import nextcord
from nextcord.ext import commands
import requests
import json

# Server list
servers = {
    'Starcommunity 1': '103.91.190.189',
    'Starcommunity 2': '103.91.190.68',
    'Starcommunity 3': '103.208.27.132',
    'Starcommunity 4': '103.91.190.230',
    'Starcommunity 5': '103.208.27.17',
    'Starcommunity 6': '103.208.27.176',
    'Starcommunity 7': '103.91.190.164',
    'Starcommunity 8': '103.91.190.171',
    'Starcommunity 9': '103.91.190.103',
    'Starcommunity 10': '103.91.190.233'
}

PORT = '30120'

class ListCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='list')
    async def list_players(self, ctx):
        embed = nextcord.Embed(
            title="กรุณาเลือกเซิร์ฟเวอร์",
            description="เลือกเซิร์ฟเวอร์ที่คุณต้องการเพื่อดูข้อมูลผู้เล่น",
            color=nextcord.Color.blurple()
        )

        options = [
            nextcord.SelectOption(label=server_name, value=server_ip)
            for server_name, server_ip in servers.items()
        ]

        select = nextcord.ui.Select(placeholder="เลือกเซิร์ฟเวอร์ที่ต้องการ", min_values=1, max_values=1, options=options)

        async def select_callback(interaction: nextcord.Interaction):
            server_ip = select.values[0]

            searching_embed = nextcord.Embed(
                title="กำลังค้นหา...",
                description="โปรดรอสักครู่ ข้อมูลกำลังถูกดึงจากเซิร์ฟเวอร์",
                color=nextcord.Color.orange()
            )
            message = await ctx.send(embed=searching_embed)

            await self.send_player_list(ctx.author, server_ip, ctx)

            await message.delete()
            await interaction.message.delete()

        select.callback = select_callback

        view = nextcord.ui.View()
        view.add_item(select)

        await ctx.send(embed=embed, view=view)
        await ctx.message.delete()

    async def send_player_list(self, user, server_ip, ctx):
        url = f'https://itools.zone/fivem/?ip_address={server_ip}&port={PORT}'

        try:
            # Request data from the external API
            response = requests.get(url)

            if response.status_code == 200:
                data = response.json()

                if "players" not in data:
                    await user.send(f"ไม่พบข้อมูลผู้เล่นจากเซิร์ฟเวอร์ {server_ip}.")
                    await ctx.send(f"ไม่พบข้อมูลผู้เล่นจากเซิร์ฟเวอร์ {server_ip}.")
                    return

                players = data["players"]
                server_name = data.get("servername", "ไม่พบชื่อเซิร์ฟเวอร์")

                sorted_players = sorted(players, key=lambda x: x['name'])

                player_list = ""
                online_count = len(players)
                for player in sorted_players:
                    player_list += f"**ID:** {player['id']}\n**Name:** {player['name']}\n\n"

                if player_list:
                    max_length = 2048
                    await user.send(f"ค้นหาเสร็จสิ้น! ข้อมูลผู้เล่นจากเซิร์ฟเวอร์ **{server_name}** จำนวนผู้เล่นออนไลน์: **{online_count}** กำลังถูกส่ง...")

                    for i in range(0, len(player_list), max_length):
                        embed = nextcord.Embed(
                            title=f"ข้อมูลผู้เล่นจากเซิร์ฟเวอร์ {server_name}",
                            description=player_list[i:i + max_length],
                            color=nextcord.Color.green()
                        )
                        await user.send(embed=embed)

                    response_embed = nextcord.Embed(
                        title="ข้อมูลผู้เล่น",
                        description="ข้อมูลผู้เล่นได้ถูกส่งไปยัง DM ของคุณแล้ว!",
                        color=nextcord.Color.green()
                    )
                    await ctx.send(embed=response_embed)

                    view = nextcord.ui.View()
                    button = nextcord.ui.Button(label="ลบประวัติแชท", style=nextcord.ButtonStyle.danger)

                    async def button_callback(interaction):
                        async for message in user.dm_channel.history(limit=100):
                            if message.author == self.bot.user:
                                await message.delete()
                        await interaction.response.send_message("ประวัติแชทถูกลบแล้ว!", ephemeral=True)

                    button.callback = button_callback
                    view.add_item(button)

                    await user.send(view=view)
                else:
                    await user.send("ไม่พบผู้เล่นในเซิร์ฟเวอร์นี้")
                    await ctx.send("ไม่พบผู้เล่นในเซิร์ฟเวอร์นี้")
            else:
                await user.send(f"ไม่สามารถดึงข้อมูลจากเซิร์ฟเวอร์. Status code: {response.status_code}")
                await ctx.send(f"ไม่สามารถดึงข้อมูลจากเซิร์ฟเวอร์. Status code: {response.status_code}")

        except Exception as e:
            await user.send(f"เกิดข้อผิดพลาด: {str(e)}")
            await ctx.send(f"เกิดข้อผิดพลาด: {str(e)}")

def setup(bot):
    bot.add_cog(ListCog(bot))
